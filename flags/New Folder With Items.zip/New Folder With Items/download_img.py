import json
import requests
import os

# Load JSON data from a file
with open('flags.json', 'r') as file:
    data = json.load(file)

# Create a directory to save images
if not os.path.exists('flags_images'):
    os.makedirs('flags_images')

# Download images
for item in data:
    img_url = item['img']
    pokemon_name = item['country_name'].lower()  # To avoid issues with file naming
    response = requests.get(img_url)

    if response.status_code == 200:
        # Save the image
        img_path = os.path.join('flags_images', f"{pokemon_name}.jpg")
        with open(img_path, 'wb') as f:
            f.write(response.content)
        print(f"Downloaded: {pokemon_name}.jpg")
    else:
        print(f"Failed to download: {img_url}")
