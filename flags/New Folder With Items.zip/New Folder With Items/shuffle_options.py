import json
import random

# Load existing JSON data from a file
with open('flags.json', 'r') as json_file:
    data = json.load(json_file)

# Shuffle options for each country
for entry in data:
    random.shuffle(entry["options"])

# Output the modified JSON data to a new file
with open('shuffled_flags.json', 'w') as json_file:
    json.dump(data, json_file, indent=4)

print("Options have been shuffled and saved to 'shuffled_flags.json'.")
